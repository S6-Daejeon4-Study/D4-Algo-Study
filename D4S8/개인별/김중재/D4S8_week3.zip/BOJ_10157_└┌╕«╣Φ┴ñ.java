package d4s8.week3;

import java.util.Scanner;

public class BOJ_10157_자리배정 {
	static int C, R, K; // 행 , 열 , 찾는 자리
	static int[][] map;
	static int dir = 0;

	// 우 하 좌 상 : 시계방향
	static int[] dx = { 0, 1, 0, -1 };
	static int[] dy = { 1, 0, -1, 0 };

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		C = sc.nextInt();
		R = sc.nextInt();
		map = new int[C][R];
		K = sc.nextInt();
		
		if(K > C*R) {
			System.out.println(0);
			return;
		}

		int nowi = 0;
		int nowj = 0;
		map[nowi][nowj] = 1;

		while (true) {
			/**순서 주의. K가 1일 경우까지 생각해야함.*/
			if (map[nowi][nowj] == K) {
				System.out.println(++nowi + " " + ++nowj);
				return;
			}
			
			int nx = nowi + dx[dir];
			int ny = nowj + dy[dir];
			if (nx < 0 || nx >= C || ny < 0 || ny >= R || map[nx][ny] > 0) {
				dir = (dir + 1) % 4;
				continue;
			}
			map[nx][ny] = map[nowi][nowj] + 1;
			nowi = nx;
			nowj = ny;
		}
	}
}
