package d4s8.week3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BOJ_1592_영식이와친구들 {
	static int N, M, L; 	// 번호, 종료조건, 분기조건
	static int[] arr;		// 각자 몇번 받았는지 기록하는 배열
	static int cnt, idx;	// 몇번 주고 받는지 횟수 , 시작 번호

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());
		L = Integer.parseInt(st.nextToken());
		arr = new int[N + 1];

		cnt = 0;		
		idx = 1;		
		arr[idx]++;

		while (true) {
			if (arr[idx] == M) {	// 해당 자리에서 M번 받았다면 종료
				System.out.println(cnt);
				return;
			}
			if (arr[idx] % 2 != 0) {	// 해당 번호에서 홀수번 받았다면 시계방향으로 진행
				idx = (idx + L) % N;
			} else {					// 해당 번호에서 짝수번 받았다면 시계방향으로 진행
				if (L >= idx) {
					idx = N + (idx - L);
				} else {
					idx = idx - L;
				}
			}
			idx = idx == 0 ? N : idx;	// %N 연산을 해서 마지막 번호가 0으로 되기 때문에 필요
			arr[idx]++;	// 공 받았으니 +1 해줌.
			cnt++;		// 공 던졌으니 +1 해줌.
		}
	}
}
