package d4s8.week3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BOJ_10163_색종이 {
	static int N;
	static int[][] map;
	static int[] count;
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N= Integer.parseInt(br.readLine());
		map = new int[1001][1001];
		count = new int[N+1];
		for(int c=1;c<=N;c++) {
			StringTokenizer st = new StringTokenizer(br.readLine()," ");
			int x = Integer.parseInt(st.nextToken());
			int y = Integer.parseInt(st.nextToken());
			int width = Integer.parseInt(st.nextToken());
			int height = Integer.parseInt(st.nextToken());
			
			for(int i=x;i<x+width;i++) {
				for(int j=y;j<y+height;j++) {
					map[i][j] = c;
				}
			}
		}
		for(int i=0;i<1001;i++) {
			for(int j=0;j<1001;j++) {
				count[map[i][j]]++;
			}
		}
		for(int i=1;i<=N;i++) {
			System.out.println(count[i]);
		}
	}
}
