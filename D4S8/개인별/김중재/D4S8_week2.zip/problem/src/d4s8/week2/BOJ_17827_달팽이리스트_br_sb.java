package d4s8.week2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * 계속 시간초과나서 BufferedReader와 StringBuilder를 사용해서 다시
 * 시도해봐도 시간초과가남.
 * => 반복문 도는 로직이 아님.
 */

import java.util.Scanner;
import java.util.StringTokenizer;

public class BOJ_17827_달팽이리스트_br_sb {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//		Scanner sc = new Scanner(System.in);
		StringTokenizer st = new StringTokenizer(br.readLine());
		int N = Integer.parseInt(st.nextToken());
		int M = Integer.parseInt(st.nextToken());
		int V = Integer.parseInt(st.nextToken());
		Node[] arr = new Node[N];
		StringBuilder sb = new StringBuilder();
		
		st = new StringTokenizer(br.readLine());
		for(int i=0;i<N-1;i++) {
			arr[i] = new Node(Integer.parseInt(st.nextToken()), i+1);
		}
		arr[N-1] = new Node(Integer.parseInt(st.nextToken()), V-1);
		
		for(int i=0;i<M;i++) {
			Node cur = arr[0];
			int cnt = 0;
			int n = Integer.parseInt(br.readLine());
			
			/*민달팽이 리스트*/
			if(V ==N && n >=N) {
				sb.append(arr[N-1].data);
				sb.append("\n");
//				System.out.println(arr[N-1].data);
				continue;
			}
			
			/*사이클을 돌게되면 반복의 횟수를 줄여주기 위해  n을 다시 재정의함.*/
			if(n >= N) {
				n = (n-N) % (N-(V-1));
				cur = arr[V-1];
			}
			
			while(true) {
				if(cnt == n) {
					sb.append(cur.data);
					sb.append("\n");
//					System.out.println(cur.data);
					break;
				}
				cur = arr[cur.nextIdx];
				cnt++;
			}
		}
		System.out.println(sb.toString());
	}
	
	private static class Node{
		int data;		// 값
		int nextIdx;	// 다음 인덱스
		
		public Node(int data, int nextIdx) {
			super();
			this.data = data;
			this.nextIdx = nextIdx;
		}
	}
}
