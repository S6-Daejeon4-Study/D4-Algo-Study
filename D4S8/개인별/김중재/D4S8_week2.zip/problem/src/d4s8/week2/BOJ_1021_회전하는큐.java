package d4s8.week2;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/***
 * 원래 덱 쓸려고했는데 indexOf 가 없어서 연결리스트로 바꿈.
로직
1. 연결리스트에 순서대로 저장
2. 없애려는 수의 인덱스를 indexOf 로 구함.
3. 왼쪽으로 움직일지 오른쪽으로 움직일지 결정
4. move2,move3 함수를 통해 움직이고 연산횟수 더하기.
5. 없애려는수가 맨앞이므로 remove(0)
 * @author Kim
 *
 */

public class BOJ_1021_회전하는큐 {
	static List<Integer> list;
	static int cnt;
	static int N,M;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		list = new LinkedList<Integer>();
		N = sc.nextInt();
		M = sc.nextInt();
		cnt = 0;
		
		for(int i=1;i<=N;i++) {
			list.add(i);
		}
		/*리스트 입력 완료*/
		
		for(int i=0;i<M;i++) {
			int num = sc.nextInt();
			int idx = list.indexOf(num);	// 리스트가 계속 이동하기 때문에 입력된 수가 위치한 인덱스를 찾기 위해 사용.
			if(idx !=0) {
				/*left, right : 입력된 num을 제거하기 위해 list의 맨 앞으로 이동시키는 횟수.*/
				int left = idx;
				int right = list.size() - idx;	
				if(left < right)	// 왼쪽으로 이동하는게 더 빠른 경우.
					move2(left);	// 2번 연산
				else				// 오른쪽으로 이동하는게 더 빠른 경우.
					move3(right);	// 3번 연산
			}
			list.remove(0);	// 입력된 num을 제거.
		}
		
		/*결과 출력*/
		System.out.println(cnt);
	}

	private static void move3(int right) {
		// TODO Auto-generated method stub
		for (int i = 0; i < right; i++) {
			list.add(0,list.remove(list.size()-1));	// 맨뒤에꺼를 빼서 맨 앞에 추가.
			cnt++;
		}
	}

	private static void move2(int left) {
		// TODO Auto-generated method stub
		for (int i = 0; i < left; i++) {
			list.add(list.remove(0));	// 맨앞에꺼를 빼서 맨 뒤에 추가.
			cnt++;
		}
	}
}
