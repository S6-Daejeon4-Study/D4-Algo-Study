package d4s8.week2;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * 예시가 잘 출력되어서 잘되는줄알고 착각해 제출을 안했는데
 * 틀렸다고 떠서 하다가 말았음,.
 * @author Kim
 */

public class BOJ_1406_에디터 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		List<Character> editor = new LinkedList<Character>();
		
		String str = sc.next();
		int N = str.length();
		int idx = N;
		
		for(int i=0;i<N;i++) {
			editor.add(str.charAt(i));
		}
		
		int M = sc.nextInt();	// 명령어의 갯수.
		/*커서가 맨 왼쪽인 경우는 idx=0이고, 맨 오른쪽인 경우는 idx=연결리스트의 크기
		 * 그리고 유의할 거는 삭제 작업을 할 때 현재 커서위치(idx)보다 한칸 앞에 꺼를 지워야하고,
		 * 추가 작업을 하고 나서는 커서위치(idx)를 +1 해줘야한다.
		 * */
		for(int i=0;i<M;i++) {
			String ch = sc.next();
			if(ch.equals("L") && idx > 0) {
				idx--;
			}else if(ch.equals("D") && idx < editor.size()) {
				idx++;
			}else if(ch.equals("B") && idx >0) {
				editor.remove(--idx);
			}else if(ch.equals("P")) {
				editor.add(idx++,sc.next().charAt(0));
			}
		}
		System.out.println(editor.toString());
	}
}
