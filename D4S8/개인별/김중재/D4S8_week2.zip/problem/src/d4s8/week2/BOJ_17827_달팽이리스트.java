package d4s8.week2;

/**
 * 맨 처음엔 연결리스트를 구현 하라는건줄 알았는데 
 * 다시 생각해보니 내부 클래스 선언해서 연결리스트 비슷하게 사용하면 될꺼 같다고 생각.
 * 
 * 근데 계속 시간초과,,,,흠,,
 */

import java.util.Scanner;

public class BOJ_17827_달팽이리스트 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int M = sc.nextInt();
		int V = sc.nextInt();
		Node[] arr = new Node[N];
		StringBuilder sb = new StringBuilder();
		
		for(int i=0;i<N-1;i++) {
			arr[i] = new Node(sc.nextInt(), i+1);
		}
		arr[N-1] = new Node(sc.nextInt(), V-1);
		
		for(int i=0;i<M;i++) {
			Node cur = arr[0];
			int cnt = 0;
			int n = sc.nextInt();
			
			/*민달팽이 리스트*/
			if(V ==N && n >=N) {
				sb.append(arr[N-1].data);
				sb.append("\n");
//				System.out.println(arr[N-1].data);
				continue;
			}
			
			/*사이클을 돌게되면 반복의 횟수를 줄여주기 위해  n을 다시 재정의함.*/
			if(n >= N) {
				n = (n-N) % (N-(V-1));
				cur = arr[V-1];
			}
			
			while(true) {
				if(cnt == n) {
					sb.append(cur.data);
					sb.append("\n");
//					System.out.println(cur.data);
					break;
				}
				cur = arr[cur.nextIdx];
				cnt++;
			}
		}
		System.out.println(sb.toString());
	}
	
	private static class Node{
		int data;		// 값
		int nextIdx;	// 다음 인덱스
		
		public Node(int data, int nextIdx) {
			super();
			this.data = data;
			this.nextIdx = nextIdx;
		}
	}
}
