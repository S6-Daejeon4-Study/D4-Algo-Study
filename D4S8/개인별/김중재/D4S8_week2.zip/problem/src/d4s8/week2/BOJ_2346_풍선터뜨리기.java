package d4s8.week2;

/*좋은 입력예시 
 * 5
 *-5 -5 -5 -5 -5
 **/

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class BOJ_2346_풍선터뜨리기 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		List<Node> arr = new LinkedList<Node>();

		for (int i = 1; i <= N; i++) {
			arr.add(new Node(i, sc.nextInt()));
		}

		int idx = 0;
		while (arr.size() > 1) {	// 하나 남았으면 의미가 없으므로 탈출
			System.out.print(arr.get(idx).i + " ");
			int data = arr.get(idx).data;
			arr.remove(idx);
			
			if (data > 0) {	// 오른쪽으로 이동 하는 경우
				idx = (idx + data - 1) % arr.size();	// 리스트의 크기보다 커질 수 있으므로 나머지 연산 수행.
			} else {	// 왼쪽으로 이동 하는 경우
				int num = idx + data;
				
				if (num < 0) {	// 리스트 범위를 벗어난다면 뒤에서 부터 해당 인덱스를 찾아야 됨.
					int a = Math.abs(num) % arr.size();	// 뒤에서부터 얼마나 더 가야되는지
					idx = a == 0 ? 0 : arr.size() - a;	// a가 0이 되면 idx를 0으로 해주고, 아니라면 뒤에서 부터 차이나는 만큼 뺀 값을 idx로 해줌.
				} else {
					idx = num;	// 리스트 범위 벗어나지 않는다면 딱히 계산식이 더 필요하지 않음.
				}
			}
		}
		System.out.print(arr.get(0).i + " ");	// 마지막은 어차피 하나밖에 없으므로 그냥 출력.
	}

	private static class Node {
		int i;
		int data;

		public Node(int i, int data) {
			super();
			this.i = i;
			this.data = data;
		}
	}
}